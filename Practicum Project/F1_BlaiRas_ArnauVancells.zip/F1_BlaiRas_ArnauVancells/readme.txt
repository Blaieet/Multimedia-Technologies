La carpeta jar cont� el fitxer .jar corresponent al projecte.
La carpeta ProjectePractiques cont� el projecte de NetBeans.

Per a executar-lo nom�s fa falta executar: "java -jar jar/ProjectePractiques.jar -i "path input"

Els par�metres del programa es poden veure fent servir:
"java -jar jar/ProjectePractiques.jar -help 1"

Per default, les imatges es guardar�n a "saved_images.zip"
No hi ha variables booleanes, per tant sempre s'haur� d'escriure el valor 1 
per a activar una opci� com per exemple:
 --negative 1
 --encoding 1
 --batch 1
...


